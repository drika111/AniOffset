bl_info = {
    "name": "Ani Offset",
    "author": "Drika111",
    "version": (3, 2),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Ani Offset",
    "description": "Propagate pose offsets to keyframes inside the selected Action+Slot frame range once per click.",
    "category": "Animation",
}

import bpy
from bpy.props import BoolProperty, IntProperty, EnumProperty, PointerProperty
from bpy.types import Panel, PropertyGroup, Operator

_last_pose_state = {}
_handlers_enabled = False

# -------------------------------------------------------------
# UTILITIES
# -------------------------------------------------------------

def get_selected_pose_bones(obj):
    sel = [pb for pb in obj.pose.bones if pb.select]
    return sel if sel else list(obj.pose.bones)

def get_actions(self, context):
    items = [(a.name, a.name, "") for a in bpy.data.actions]
    return items if items else [("NONE", "(No Actions)", "")]

def get_slots(self, context):
    action_name = context.scene.bone_offset_props.target_action
    action = bpy.data.actions.get(action_name)
    items = []
    if not action or not hasattr(action, "slots"):
        return [("NONE", "(No slots for this Action)", "")]
    for slot in action.slots:
        label = getattr(slot, "name_display", None) or getattr(slot, "identifier", None) or str(slot.handle)
        user_names = []
        if hasattr(slot, "users"):
            for user_id in slot.users():
                if hasattr(user_id, "bl_rna") and user_id.bl_rna.identifier == 'Object':
                    obj = bpy.data.objects.get(user_id.name)
                    if obj and obj.type == 'ARMATURE':
                        user_names.append(obj.name)
        users_str = ", ".join(user_names) if user_names else "(no user)"
        items.append((str(slot.handle), f"{label} (Armatures: {users_str})", ""))
    return items if items else [("NONE", "(No slots found)", "")]

def get_slot_by_handle(action, handle_str):
    if not action or not hasattr(action, "slots"):
        return None
    for s in action.slots:
        if str(getattr(s, "handle", None)) == handle_str:
            return s
    return None

def get_slot_channelbag(action, slot_handle_str):
    slot = get_slot_by_handle(action, slot_handle_str)
    if not slot:
        return None
    layers = getattr(action, "layers", None)
    if not layers:
        return None
    for layer in layers:
        strips = getattr(layer, "strips", None) or []
        for strip in strips:
            cb = getattr(strip, "channelbag", None)
            if cb:
                try:
                    return cb(slot)
                except Exception:
                    return getattr(strip, "channelbag", None)
    return None

def get_fcurves_from_channelbag(channelbag, bone_name, prop, idx):
    if not channelbag:
        return []
    prefix = f'pose.bones["{bone_name}"].{prop}'
    return [fc for fc in getattr(channelbag, "fcurves", []) if fc.data_path == prefix and fc.array_index == idx]

def get_fcurves_from_action(action, bone_name, prop, idx):
    if not action:
        return []
    prefix = f'pose.bones["{bone_name}"].{prop}'
    return [fc for fc in action.fcurves if fc.data_path == prefix and fc.array_index == idx]

def capture_pose_state(context):
    obj = context.object
    if not obj or obj.type != "ARMATURE" or context.mode != "POSE":
        return {}
    pose_state = {}
    for pb in get_selected_pose_bones(obj):
        pose_state[pb.name] = {
            "location": pb.location.copy(),
            "rotation_quaternion": pb.rotation_quaternion.copy(),
            "rotation_euler": pb.rotation_euler.copy(),
            "scale": pb.scale.copy(),
        }
    return pose_state

# -------------------------------------------------------------
# OPERATOR: CAPTURE POSE
# -------------------------------------------------------------
class BONEOFFSET_OT_capturepose(Operator):
    bl_idname = "boneoffset.capture_pose"
    bl_label = "Capture Pose"
    bl_description = "Capture the current pose as reference for offset propagation"
    bl_options = {'REGISTER'}
    def execute(self, context):
        global _last_pose_state
        obj = context.object
        if not obj or obj.type != "ARMATURE" or context.mode != "POSE":
            self.report({'WARNING'}, "Select an armature in Pose mode")
            return {'CANCELLED'}
        _last_pose_state.clear()
        for pb in get_selected_pose_bones(obj):
            _last_pose_state[pb.name] = {
                "location": pb.location.copy(),
                "rotation_quaternion": pb.rotation_quaternion.copy(),
                "rotation_euler": pb.rotation_euler.copy(),
                "scale": pb.scale.copy(),
            }
        self.report({'INFO'}, f"Captured pose for {len(_last_pose_state)} bone(s) at frame {context.scene.frame_current}")
        return {'FINISHED'}

# -------------------------------------------------------------
# OPERATOR: PROPAGATE ONCE
# -------------------------------------------------------------
class BONEOFFSET_OT_propagate(Operator):
    bl_idname = "boneoffset.propagate"
    bl_label = "Propagate Offset"
    bl_description = "Apply pose offset ONCE to all keyframes in range for chosen Action/Slot"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        global _last_pose_state
        props = context.scene.bone_offset_props
        obj = context.object
        if not obj or obj.type != "ARMATURE" or context.mode != "POSE":
            self.report({'WARNING'}, "Select an armature in Pose mode")
            return {'CANCELLED'}
        action = bpy.data.actions.get(props.target_action)
        slot_handle = props.target_slot
        frame = context.scene.frame_current
        start, end = props.first_frame, props.last_frame
        channelbag = None
        if action and slot_handle and slot_handle != "NONE":
            channelbag = get_slot_channelbag(action, slot_handle)
        action_fallback = action if channelbag is None else None
        # --- pose state to compare ---
        before = _last_pose_state
        after = capture_pose_state(context)
        selected = get_selected_pose_bones(obj)
        changed = 0
        for pb in selected:
            before_pb = before.get(pb.name)
            after_pb = after.get(pb.name)
            if not before_pb or not after_pb:
                continue
            for prop in ("location", "rotation_quaternion", "rotation_euler", "scale"):
                length = len(after_pb[prop])
                for i in range(length):
                    offset = after_pb[prop][i] - before_pb[prop][i]
                    if abs(offset) < 1e-6:
                        continue
                    if channelbag:
                        for fc in get_fcurves_from_channelbag(channelbag, pb.name, prop, i):
                            for kp in fc.keyframe_points:
                                if start <= kp.co.x <= end and kp.co.x != frame:
                                    kp.co.y += offset
                                    changed += 1
                            fc.update()
                    if action_fallback:
                        for fc in get_fcurves_from_action(action_fallback, pb.name, prop, i):
                            for kp in fc.keyframe_points:
                                if start <= kp.co.x <= end and kp.co.x != frame:
                                    kp.co.y += offset
                                    changed += 1
                            fc.update()
        # Only update _last_pose_state after propagation so offsets are not summed
        _last_pose_state.clear()
        for pb in selected:
            _last_pose_state[pb.name] = after.get(pb.name)
        self.report({'INFO'}, f"Anim Offset: {changed} keyframes offset.")
        return {'FINISHED'}

# -------------------------------------------------------------
# OPERATOR: TOGGLE ON/OFF
# -------------------------------------------------------------
class BONEOFFSET_OT_toggle(Operator):
    bl_idname = "boneoffset.toggle"
    bl_label = "Enable/Disable Addon"
    bl_description = "Turn Anim Offset Pro on or off (handlers only active when ON)"
    is_enable: BoolProperty()
    def execute(self, context):
        global _handlers_enabled, _last_pose_state
        props = context.scene.bone_offset_props
        props.is_enabled = self.is_enable
        if self.is_enable and not _handlers_enabled:
            _handlers_enabled = True
            self.report({'INFO'}, "Anim Offset Pro enabled: you can now Capture Pose and Propagate Offset.")
        elif not self.is_enable and _handlers_enabled:
            _handlers_enabled = False
            _last_pose_state.clear()
            self.report({'INFO'}, "Anim Offset Pro disabled: handlers removed, state cleared.")
        return {'FINISHED'}

# -------------------------------------------------------------
# PROPERTY GROUP
# -------------------------------------------------------------

class BoneOffsetProperties(PropertyGroup):
    is_enabled: BoolProperty(
        name="Addon Enabled",
        description="Enable Anim Offset Pro (capture/propagate only works when enabled)",
        default=False
    )
    target_action: EnumProperty(
        name="Action",
        description="Action to modify",
        items=get_actions
    )
    target_slot: EnumProperty(
        name="Slot",
        description="Slot inside Action",
        items=get_slots
    )
    first_frame: IntProperty(name="Start Frame", default=1)
    last_frame: IntProperty(name="End Frame", default=250)

# -------------------------------------------------------------
# PANEL
# -------------------------------------------------------------

class BONEOFFSET_PT_panel(Panel):
    bl_label = "Ani Offset"
    bl_idname = "BONEOFFSET_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Ani Offset"
    def draw(self, context):
        props = context.scene.bone_offset_props
        layout = self.layout
        if not props.is_enabled:
            layout.operator("boneoffset.toggle", text="Turn ON", icon='FILE_MOVIE').is_enable = True
            layout.label(text="Enable to use capture/propagate.")
            layout.label(text="by Drika111")
            return
        layout.operator("boneoffset.toggle", text="Turn OFF", icon='RECORD_ON').is_enable = False
        layout.prop(props, "target_action")
        layout.prop(props, "target_slot")
        row = layout.row(align=True)
        row.prop(props, "first_frame")
        row.prop(props, "last_frame")
        layout.operator("boneoffset.capture_pose", icon='PINNED')
        layout.operator("boneoffset.propagate", icon='CHECKBOX_HLT')
        layout.label(text="by Drika111")

# -------------------------------------------------------------
# REGISTER
# -------------------------------------------------------------

classes = (
    BoneOffsetProperties,
    BONEOFFSET_OT_capturepose,
    BONEOFFSET_OT_propagate,
    BONEOFFSET_OT_toggle,
    BONEOFFSET_PT_panel,
)

def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.bone_offset_props = PointerProperty(type=BoneOffsetProperties)

def unregister():
    del bpy.types.Scene.bone_offset_props
    for c in reversed(classes):
        bpy.utils.unregister_class(c)

if __name__ == "__main__":
    register()